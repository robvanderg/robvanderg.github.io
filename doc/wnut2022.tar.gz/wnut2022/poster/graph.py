import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
plt.style.use('rob.mplstyle')

fig, ax = plt.subplots(figsize=(8,5), dpi=300)

in_domain = [76.27, 74.99, 79.09, 83.83, 83.83]
out_domain = [55.17, 53.35, 55.67, 75.18, 75.64]

bar_width = .35
x1 = [x-bar_width/2 for x in range(len(in_domain))]
x2 = [x+bar_width/2 for x in range(len(out_domain))]
ax.bar(x1, in_domain, bar_width, label='ID')
ax.bar(x2, out_domain, bar_width, label='OOD')

ax.set_ylabel('Macro-F1')
names = 'base', 'LexNorm', 'Resample', 'Context', 'Best'
ax.set_xticks(range(len(in_domain)), names)
#plt.xticks(rotation = 45) 
ax.set_ylim((50,90))
leg = ax.legend()
leg.get_frame().set_linewidth(1.5)
fig.savefig('test.pdf', bbox_inches='tight')


