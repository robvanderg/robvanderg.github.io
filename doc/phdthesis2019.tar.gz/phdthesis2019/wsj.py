
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt
 
vals  = [89.15, 89.12]
names = ['Baseline', 'MoNoise']
y_pos = np.arange(len(names))
 
plt.bar(y_pos, vals, align='center', alpha=0.5)
plt.xticks(y_pos, names)
plt.ylabel('F1')
plt.ylim([88.0,90.0])

plt.savefig('incl/wsj.png') 
plt.show()
