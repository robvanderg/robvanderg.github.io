
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt
 
vals  = [70.85, 70.64, 71.99]
names = ['Baseline', 'pruneLess', 'MoNoise']
y_pos = np.arange(len(names))
 
plt.bar(y_pos, vals, align='center', alpha=0.5)
plt.xticks(y_pos, names)
plt.ylabel('F1')
plt.ylim([70.5,72.5])

plt.savefig('incl/prune.png') 
plt.show()
