
#wget http://nlp.ffzg.hr/data/corpora/slwac2.0.gz
#wget http://nlp.ffzg.hr/data/corpora/hrwac2.0.gz
#wget http://nlp.ffzg.hr/data/corpora/srwac1.0.gz


zcat slwac2.0.gz  | sed "s;</s>;;g" | cut -f 1 | grep -v "^<" | tr '\n' ' ' | sed "s;  ;\n;g" > slwac2.0.txt
zcat hrwac2.0.gz  | sed "s;</s>;;g" | cut -f 1 | grep -v "^<" | tr '\n' ' ' | sed "s;  ;\n;g" > hrwac2.0.txt
zcat srwac1.0.gz  | sed "s;</s>;;g" | cut -f 1 | grep -v "^<" | tr '\n' ' ' | sed "s;  ;\n;g" > srwac1.0.txt

rm slwac2.0.gz
rm hrwac2.0.gz
rm srwac1.0.gz

#TODO English
#TODO Dutch
#TODO Spanish

