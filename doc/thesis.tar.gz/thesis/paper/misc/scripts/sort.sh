sort /net/shared/rob/nlTweets/xaa --compress-program=/bin/gzip --parallel=8 -u -T /dev/shm/ > /net/shared/rob/nlTweets/xaa.sorted
