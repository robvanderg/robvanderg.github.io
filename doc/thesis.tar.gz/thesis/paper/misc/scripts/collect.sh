for dir1 in /net/corpora/twitter2/Tweets/Tekst/*; do
    for dir2 in $dir1/*; do
        for dir3 in $dir2/*; do
            zcat $dir3 | sed -r 's/.*\t//g' | grep -v "^RT" >> /net/shared/rob/nlTweets/all.txt
            echo dir3 >> done.txt
        done
    done
done

sort /net/shared/rob/nlTweets/all.txt -T /dev/shm/ | uniq | shuf > /net/shared/rob/nlTweets/noDoubles

