mkdir corpora -p
cd corpora
wget https://dumps.wikimedia.org/nlwiki/20180101/nlwiki-20180101-pages-articles-multistream.xml.bz2
wget https://dumps.wikimedia.org/enwiki/20180101/enwiki-20180101-pages-articles-multistream.xml.bz2
wget https://dumps.wikimedia.org/eswiki/20180101/eswiki-20180101-pages-articles-multistream.xml.bz2
wget https://dumps.wikimedia.org/hrwiki/20180101/hrwiki-20180101-pages-articles-multistream.xml.bz2
wget https://dumps.wikimedia.org/srwiki/20180101/srwiki-20180101-pages-articles-multistream.xml.bz2
wget https://dumps.wikimedia.org/slwiki/20180101/slwiki-20180101-pages-articles-multistream.xml.bz2

cd ../
mkdir tools -p
cd tools
git clone https://github.com/attardi/wikiextractor.git
cd wikiextractor

python3 WikiExtractor.py  -o extracted.nl ../corpora/nlwiki-20180101-pages-articles-multistream.xml.bz2
python3 WikiExtractor.py  -o extracted.en ../corpora/enwiki-20180101-pages-articles-multistream.xml.bz2
python3 WikiExtractor.py  -o extracted.es ../corpora/eswiki-20180101-pages-articles-multistream.xml.bz2
python3 WikiExtractor.py  -o extracted.hr ../corpora/hrwiki-20180101-pages-articles-multistream.xml.bz2
python3 WikiExtractor.py  -o extracted.sr ../corpora/srwiki-20180101-pages-articles-multistream.xml.bz2
python3 WikiExtractor.py  -o extracted.sl ../corpora/slwiki-20180101-pages-articles-multistream.xml.bz2

cat extracted.nl/*/* | grep -v "^<" > ../corpora/wiki.20180101.nl
cat extracted.en/*/* | grep -v "^<" > ../corpora/wiki.20180101.en
cat extracted.es/*/* | grep -v "^<" > ../corpora/wiki.20180101.es
cat extracted.hr/*/* | grep -v "^<" > ../corpora/wiki.20180101.hr
cat extracted.sr/*/* | grep -v "^<" > ../corpora/wiki.20180101.sr
cat extracted.sl/*/* | grep -v "^<" > ../corpora/wiki.20180101.sl

cd ..
git clone https://robvanderg@bitbucket.org/robvanderg/utils.git
cd utils/ngrams
icmbuild

./tmp/bin/binary ../../corpora/wiki.20180101.nl ../../corpora/wiki.nl 3
./tmp/bin/binary ../../corpora/wiki.20180101.en ../../corpora/wiki.en 3
./tmp/bin/binary ../../corpora/wiki.20180101.es ../../corpora/wiki.es 3
./tmp/bin/binary ../../corpora/wiki.20180101.hr ../../corpora/wiki.hr 3
./tmp/bin/binary ../../corpora/wiki.20180101.sr ../../corpora/wiki.sr 3
./tmp/bin/binary ../../corpora/wiki.20180101.sl ../../corpora/wiki.sl 3

