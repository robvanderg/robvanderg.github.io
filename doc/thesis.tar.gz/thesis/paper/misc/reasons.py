#http://mlm.humanities.manchester.ac.uk/wp-content/uploads/2015/12/Jones-2010_Spelling-in-computer-mediated-communication.pdf

#The changing face of spelling on the internet

data = [61, 183, 197, 112, 170, 132, 2]
names = ["It's fun", "It's faster", "It's become the norm", "It's fashionable","People are unsure of the correct spellings", "People want to represent their dialexts and/or accents", "Don't know"]



