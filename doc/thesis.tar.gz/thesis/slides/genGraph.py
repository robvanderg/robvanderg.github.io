import matplotlib.pyplot as plt


scores = [0.970527, 0.986685, 0.98828, 0.989112, 0.989459, 0.989736, 0.989806, 0.989806, 0.989806, 0.989806]

markerSize = [150] * 11
names = ['UNK', 'ALL']
plt.plot(range(1, len(scores)+1), scores, label='MoNoise')
plt.plot([1,10], [0.905, 0.905], label='Baseline')
plt.legend(loc='lower right')
plt.xlabel(r'Number of normalization candidates')
plt.ylabel('Acc.')
plt.ylim([0.9,1])

plt.savefig('incl/normPerf.png')
plt.show()

